#!/bin/bash

echo Converting .voc files to .wav files...
echo
echo
mv voc2wav PA
cd PA
for i in $( ls *.VOC ); do 
    ./voc2wav $i
done
mkdir wav
mv *.wav wav 
mv voc2wav ..
cd ..
mv voc2wav PB
cd PB
for i in $( ls *.VOC ); do 
    ./voc2wav $i
done
mkdir wav
mv *.wav wav 
mv voc2wav ..
cd ..
mv voc2wav PC
cd PC
for i in $( ls *.VOC ); do 
    ./voc2wav $i
done
mkdir wav
mv *.wav wav 
mv voc2wav ..
cd ..
mv voc2wav PD
cd PD
for i in $( ls *.VOC ); do 
    ./voc2wav $i
done
mkdir wav
mv *.wav wav 
mv voc2wav ..
cd ..
mv voc2wav PE
cd PE
for i in $( ls *.VOC ); do 
    ./voc2wav $i
done
mkdir wav
mv *.wav wav 
mv voc2wav ..
cd ..
mv voc2wav PF
cd PF
for i in $( ls *.VOC ); do 
    ./voc2wav $i
done
mkdir wav
mv *.wav wav 
mv voc2wav ..
cd ..
mv voc2wav PG
cd PG
for i in $( ls *.VOC ); do 
    ./voc2wav $i
done
mkdir wav
mv *.wav wav 
mv voc2wav ..
cd ..
mv voc2wav PH
cd PH
for i in $( ls *.VOC ); do 
    ./voc2wav $i
done
mkdir wav
mv *.wav wav 
mv voc2wav ..
cd ..
mv voc2wav PI
cd PI
for i in $( ls *.VOC ); do 
    ./voc2wav $i
done
mkdir wav
mv *.wav wav 
mv voc2wav ..
cd ..
mv voc2wav PJ
cd PJ
for i in $( ls *.VOC ); do 
    ./voc2wav $i
done
mkdir wav
mv *.wav wav 
mv voc2wav ..
cd ..
mv voc2wav PK
cd PK
for i in $( ls *.VOC ); do 
    ./voc2wav $i
done
mkdir wav
mv *.wav wav 
mv voc2wav ..
cd ..
mv voc2wav PL
cd PL
for i in $( ls *.VOC ); do 
    ./voc2wav $i
done
mkdir wav
mv *.wav wav 
mv voc2wav ..
cd ..
mv voc2wav PM
cd PM
for i in $( ls *.VOC ); do 
    ./voc2wav $i
done
mkdir wav
mv *.wav wav 
mv voc2wav ..
cd ..
mv voc2wav PN
cd PN
for i in $( ls *.VOC ); do 
    ./voc2wav $i
done
mkdir wav
mv *.wav wav 
mv voc2wav ..
cd ..
mv voc2wav PO
cd PO
for i in $( ls *.VOC ); do 
    ./voc2wav $i
done
mkdir wav
mv *.wav wav 
mv voc2wav ..
cd ..
mv voc2wav PZ
cd PZ
for i in $( ls *.VOC ); do 
    ./voc2wav $i
done
mkdir wav
mv *.wav wav 
mv voc2wav ..
cd ..
echo Conversion successful
echo