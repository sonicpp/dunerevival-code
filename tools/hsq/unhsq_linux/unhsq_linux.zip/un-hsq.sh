#!/bin/bash

# bash script to automatically unpack all .hsq files contained in the main Dune directory
# based upon the un-hsq.bat written by Borg Number One

echo Unpacking .hsq files...
echo
echo
for i in $( ls *.hsq ); do 
    ./unhsq $i $i.___
done
rename .hsq.___ .unp *.hsq.___
mkdir unpacked
mv *.unp unpacked
echo Moving files with music data to "music" directory
echo

# Creation of directory for music data.
mkdir unpacked/music
mkdir unpacked/music/hsq
mkdir unpacked/music/agd
mkdir unpacked/music/m32

# The .agd music files are compressed with hsq, too. Renaming temporarily
# all the .hsq files in .tmp and the .agd in .hsq to decompress them.
rename .hsq .tmp *.hsq
rename .agd .hsq *.agd
for i in $( ls *.hsq ); do
    ./unhsq $i $i.___
done
rename .hsq.___ .unp *.hsq.___
mv *.unp unpacked/music/agd
rename .hsq .agd *.hsq

# Doing the same for .m32 files.
rename .m32 .hsq *.m32
for i in $( ls *.hsq ); do
    ./unhsq $i $i.___
done
rename .hsq.___ .unp *.hsq.___
mv *.unp unpacked/music/m32
rename .hsq .m32 *.hsq
rename .tmp .hsq *.tmp

# Moving .hsq music files decompressed in music/hsq/.
cd unpacked
mv ARRAKIS.unp music/hsq
mv BAGDAD.unp music/hsq
mv MORNING.unp music/hsq
mv SEKENCE.unp music/hsq
mv SIETCHM.unp music/hsq
mv WARSONG.unp music/hsq
mv WATER.unp music/hsq
mv WORMSUIT.unp music/hsq
mv WORMINTR.unp music/hsq

echo Renaming files with sound data to .voc files...
echo Moving .voc files to "sounds" directory...
echo
echo
mkdir sounds
mv SD*.* sounds
cd sounds
rename .unp .voc *.unp
cd ..
echo Unpacking all .hsq files to the directory "unpacked" was successfully.
echo